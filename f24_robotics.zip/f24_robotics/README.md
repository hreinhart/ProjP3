# Repository for UA CS460/560 - Fall 2024

**Links to ROS resources**

([Short video overview](
https://vimeo.com/639236696))


Tutorials to complete: 

1. ([CLI Tools Tutorial](https://docs.ros.org/en/humble/Tutorials/Beginner-CLI-Tools.html))
2. ([Beginner Client Tutorial](https://docs.ros.org/en/humble/Tutorials/Beginner-Client-Libraries.html))


***Homework Assignment 1***

[Webots/ROS2/Heuristic Search](./Homework1/Assignment.md)
